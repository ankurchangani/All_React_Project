

const conf = {
    tinymceURL : import.meta.env.VITE_TINYMCE_URL || "ywflfjos3v5cuvx47htirdmvuoq2wxwtkmj8i8i7wzjevxew"
}

console.log(conf);

export default conf