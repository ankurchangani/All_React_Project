import { combineReducers } from "redux";
import Bookreducer from "./Reducers/Booksreducer";


 export const MainReducer = combineReducers({Bookreducer });